README.md

https://srikarchunduri.github.io/CSE160/asgn0/asg0.html